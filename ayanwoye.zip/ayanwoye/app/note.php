<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class note extends Model
{
	protected $fillable = ['body'];
	//protected $fillable = [];
	
    public function card()
	{
		return $this->belongsTo(card::class);
	}
	
	public function user()
	{
		return $this->belongsTo(user::class);
	}
}
