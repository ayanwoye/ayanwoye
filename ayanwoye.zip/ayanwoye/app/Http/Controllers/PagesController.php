<?php

namespace App\Http\Controllers;

use Illuminate\Support\Arr;
use Illuminate\Http\Request;
use App\Message;
use App\takencontrol;
use App\ayan;



class PagesController extends Controller
{
	 var $dataa = array();
    public function index(){
		
		return view('home');
	}
	public function about(){
        //$this->contact();
		return view('about');
	}
	public function contact(){
		
		return view('contact');
	}
    public function settest(){

        return view('test.settest');
    }
	public function taketest(Request $request){
       // $request->session()->flush();session()->get('_previous')['url']
       //dd(session()->get('_previous')['url']==url('taketest'));

        //dd(null>9);
        if(session('a')==null || $request->input('questions')!==null ){
            //dd('finally');
            $messages = takencontrol::all();
            $dd = json_decode(json_encode($messages), true);
            $answers =[];
            $raa =[];
            //$keyys = array_keys($dd);
            $questions =$request->input('questions') ?? count($dd);
            shuffle($dd);
            $questions=$questions>=count($dd)?count($dd):$questions;
            //dd($questions);
            $raaatt3 = 0;
            for ($question=0;$question<$questions;++$question) {
                $ddd =$dd[$raaatt3++];
                $answers[$ddd['id']]=$ddd['answer'];
                //dd($ddd);
                $raatt = array_splice($ddd, 0 ,2);
                $raatt1 = array_splice($ddd, 4 ,5);
                $keys = array_keys($ddd);
                $new=[];
                shuffle($ddd);
                $raatt3 = 0;
                foreach($keys as $key) {
                    $new[$key] = $ddd[$raatt3++];
                }
                $rr =	array_merge($raatt,$raatt1,$new);
                array_push($raa,$rr);

            }
            $messages = json_decode(json_encode($raa), false);
            session(['a'=>$messages,'answer'=>$answers]);
            //dd(session());

        }
        else{
            $messages = session('a');
        }
        //dd($request);
		return view('test/taketest')->with('messages',$messages)->with('seed','3');
	}

	public function tak(Request $request){
		$this->validate($request,['question' => 'required','one' => 'required','two' => 'required'	  ]);
		 $inputs = $request->all();
		$message = takencontrol::find($inputs['id']);

		 $message ->question = $request->input('question');
		 $message ->one = $request->input('one');
		 $message ->two = $request->input('two');
		 $message ->three = $request->input('three');
		 $message ->four = $request->input('four');
		 $message ->answer = $request->input('one');
		 //$message ->five = $request->input('five',null);
		 $message->save();
		 return redirect('/')->with('success','message sent');

		print_r($input);echo "<br>";
		echo "dfd";
	}

	public function ta(Request $request){

		 $inputs = $request->all();
		$message = takencontrol::find($inputs['id']);


		 $message->delete();
		 return redirect('/')->with('success','Question deleted');

		print_r($input);echo "<br>";
		//echo "dfd";
	}

	public function getMessages(){
		$messages = Message::all();

		return view('messages')->with('messages',$messages)->with('seed','1');
	}

	public function seeq(){
		$messages = takencontrol::all();


		return view('messages')->with('messages',$messages)->with('seed','2');

	}

	 public function taken(Request $request){
		$boy =0;
		$boboo=0;
		$answer=[];
		//var $youranswers='';
		 $inputs = $request->except(['_token','u','mm']);
		$keys = array_keys($inputs);//dd(session('answer')!==null);
		 foreach($keys as $key)
		 {
			 if( is_numeric($key) == true){
                 $answer[$key]=$inputs[$key];
				 $keke=$key."hid";
			 	if($inputs[$keke]==$inputs[$key])
						{++$boy;}
			 }
			 else{
			     ++$boboo;
             }
		 }//return back()->with('$rr',$request->old('2'));

         //session(['answer'=>$answer]);//dd($answer);

         $messages = session('a');
         return view('test/taketest',['boboo' => $boboo,'boyy'=>$boy])->with('messages',$messages)->with('youranswers',$answer)->with('seed','taken');

	}

	public function submit(Request $request){

		 $this->validate($request,['name' => 'required','email' => 'required|email|between:8,40',
		'message' => 'required'
								  ]);
		// if($request->input('name')== '') return 123;
		 $message = new Message;
		 $message ->name = $request->input('name');
		 $message ->email = $request->input('email');
		 $message ->message = $request->input('message');
		 
		 //save message
		 $message->save();
		 
		 //redirector
		 return redirect('/')->with('success','message sent');
	}
	
	public function submituploadquestion(Request $request){
		 
		 $this->validate($request,['question' => 'required','one' => 'required','two' => 'required'	  ]);
		 if($request->input('one')== '') return 123;
		 $message = new takencontrol;
		 $message ->question = $request->input('question');
		 $message ->one = $request->input('one');
		 $message ->two = $request->input('two');
		 $message ->three = $request->input('three',null);
		 $message ->four = $request->input('four',null);
		 $message ->answer = $request->input('one');
		 $message ->five = $request->input('five',null);
		 $message->save();

		 return redirect('/')->with('success','Question Upload');
	}
	
}
