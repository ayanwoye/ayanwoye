<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\card;
use App\note;

class CardController extends Controller
{
	public function index(){
		
		$cards = card::all();
		return view('welcome')->with('cards',$cards);
		    //\DB::table('cards')->get();
	}
	
	public function one(card $card){
		
		//$ss=note::find(where( card_id=1));
		$card->load('notes.user');
		//return $card;
		return view('card.show')->with('card',$card);
		
	}
	
	public function editnote(note $note){
		
		$ss = card::find($note->card_id);
		//$ss=$note->card()->get();
		return view('card.editnote')->with('card',$note)->with('ss',$ss);
		
	}
	
	public function updatenote(Request $request,note $note){
		
		//$card = $note->load('card');
		$note->update(['body'=>$request->body]);
		$card = card::find($note->card_id);
		//var_dump($card);
		return back();
		//return view('card/show')->with('card',$card);
		
	}
	
	public function addnote(Request $request,card $card){
		
		//$message = new note;
//		 $message ->body = $request->input('body');
//		 $card->notes()->save($message);'user_id'=>'1',
		$this->validate($request,['body' => 'required|min:10'  ]);
		$note = new note(['body'=>$request->body]);
		//$note->user_id=1;
		$card->addnote($note,1);
			
			
		return back();
		
	}
	
}
