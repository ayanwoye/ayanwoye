<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class card extends Model
{
    public function notes()
	{
		return $this->hasMany(note::class);
	}
	
	public function path()
	{
		return '/card/'.$this->id;
	}
	
	public function addnote(note $note,$userid)
	{
		$note->user_id = $userid;
		return $this->notes()->save($note);
		 //'/card/'.$this->id;
	}
}
