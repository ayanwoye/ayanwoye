<div class="jumbotron text-uppercase text-center">
	<h1>
	<?php if(auth()->guard()->check()): ?>
		<?php echo e(Auth::user()->name); ?> 
	<?php endif; ?>
	</h1>
	<h2> welcome to hope and anchor home page</h2>
	<div class="lead">
	This is powered by the kaffin koro division </div>
</div><?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/inc/greet.blade.php ENDPATH**/ ?>