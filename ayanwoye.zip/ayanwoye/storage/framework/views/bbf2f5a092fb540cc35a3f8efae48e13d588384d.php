       
   <?php $__env->startSection('head'); ?>
   
    <script type="text/javascript">
	
	function block_rightclick(event){
		//return false;

	}
	</script>

   <?php $__env->stopSection(); ?>
   <?php $__env->startSection('content'); ?>
	   <?php if(count($errors)>0): ?>
		  <?php $__currentLoopData = $errors-> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  <div class="alert alert-danger">
				<?php echo e($erro); ?>

			  </div>
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	   <?php endif; ?>
			<div class="alert alert-info">
				<a class="btn btn-link"  href="<?php echo e(url('/taketest')); ?>">   Retake Test</a>
				<a class="btn btn-link"  href="<?php echo e(url('/taketest')); ?>">   Quck Test</a>
				<a class="btn btn-link"  href="<?php echo e(url('/taketest')); ?>">   Quiz</a>
				<a class="btn btn-link" href="<?php echo e(url('/settest')); ?>">Custom Test</a>
				<a class="btn btn-link" href="<?php echo e(url('/')); ?>">Take Another</a>
				<a class="btn btn-warning" href="<?php echo e(url('/')); ?>">Marking Sheet</a>

			</div>


	   <?php echo Form::open(['url' => "taketest/submit?u=ss"]); ?>


						<?php
						$number=0;
						if(session('a')!=null){
							$messages = session('a');
						}
						  ?>
					<?php if(count($messages)>0 && $seed=='3'): ?>
						  <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="form-group">
										<?php
										$boy=$message->id."hid";
										$boys=$message->answer;
										$boyss= utf8_encode($boys);
										?>
							    <?php echo e(Form::hidden($boy, $boyss)); ?>

							    Question:<?php echo e(++$number); ?>   <?php echo e($message->question); ?> <br />
										<?php $boy=$message->one.$message->created_at;  ?>
								<?php echo e(Form::radio($message->id, $message->one,false,['id' => $boy ])); ?>

								<?php echo e(Form::label($boy , $message->one)); ?>

										<?php $boy=$message->two.$message->created_at; ?>
								<?php echo e(Form::radio($message->id, $message->two,false,['id' => $boy])); ?>

								<?php echo e(Form::label($boy, $message->two)); ?>

										<?php $boy=$message->three.$message->created_at; ?>
								<?php echo e(Form::radio($message->id, $message->three,false,['id' => $boy])); ?>

											<?php echo e(Form::label($boy, $message->three)); ?>


								<?php $boy=$message->four.$message->created_at;  ?>
								<?php echo e(Form::radio($message->id, $message->four,false,['id' => $boy])); ?>

								<?php echo e(Form::label($boy, $message->four)); ?>

							</div>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  <div >
							  <?php echo e(Form::Submit('Submit', ['class'=>'btn btn-primary','onclick'=>"bb()"])); ?>

						  </div>
					<?php elseif(count($messages)>0 && $seed=='taken'): ?>
						<div class="alert alert-danger">
							Your score is <?php echo e($boyy); ?> out of <?php echo e($boboo); ?>


						</div>
						<div >
							<div id="buttonss" class="btn btn-warning">
								Show Analysis
							</div>
							<div id="buttonss" class="btn btn-primary">
								Take Another

							</div>
							<button class="btn btn-info" type="button">
								Retake Test

							</button>
						</div>
						<div id="result_check">
						  <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <div class="form-group"  >
								  <?php
								  $boy=$message->id."hid";
								  $boys=$message->answer;
								  $boyss= utf8_encode($boys);
								  ?>
								  <ul class="list-group">
									  <li class="list-group-item">
										  Question:<?php echo e(++$number); ?>   <?php echo e($message->question); ?> <br />
									  </li>
									  <li class="list-group-item " style="">
										  Answer:   <?php echo e($message->answer); ?> <br />
									  </li>
									  <li class="list-group-item"><?php  ?>
										  Your Answer:   <?php echo e(isset($youranswers[$message->id])?$youranswers[$message->id]:'No answer given'); ?> <br />
									  </li>
									  <li class="list-group-item">
										  Given Options:
										  <ol class=""><?php echo e($message->one); ?></ol>
										  <ol><?php echo e($message->two); ?></ol>
										  <ol><?php echo e($message->three); ?></ol>
										  <ol><?php echo e($message->four); ?></ol>
									  </li>
								  </ul>
							  </div>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<div >
								<div id="buttonss" class="btn btn-warning">
									Show Analysis
								</div>
								<div id="buttons" class="btn btn-primary">
									Take Another
								</div>
								<button class="btn btn-info" type="button">
									Retake Test
								</button>
							</div>
						</div>
					<?php endif; ?>
	   <?php echo Form::close(); ?>

	   <script type="text/javascript">

		   $( document ).ready(function() {$('#result_check').hide();});
		   $( '.btn-warning').click(function() {
			   $('#result_check').toggle();
			   $(this).html()=="Hide Analysis"?$(this).html("Show Analysis"):$(this).html("Hide Analysis");
		   });
	   </script>
   <?php $__env->stopSection(); ?>
   
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/test/taketest.blade.php ENDPATH**/ ?>