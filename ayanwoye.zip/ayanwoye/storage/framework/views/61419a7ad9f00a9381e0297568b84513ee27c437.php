<?php $__env->startSection('content'); ?>
<h1>Contact</h1>
		<?php if(count($errors)>0): ?>
		 	  <?php $__currentLoopData = $errors-> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		 	  <div class="alert alert-danger">
		 	  	<?php echo e($erro); ?>

		 	  </div>
		 	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 	<?php endif; ?>

<?php echo Form::open(['url' => 'contact/submit']); ?>

  <div class="">
	   <div class="form-group">
		<?php echo e(Form::label('name', '')); ?>

		<?php echo e(Form::text('name', '',['placeholder' => 'Enter Name','class'=>'form-control'])); ?>

	   </div>
	   <div class="form-group">

		<?php echo e(Form::label('email', '')); ?>

		<?php echo e(Form::text('email', '',['placeholder' => 'Enter Email','class'=>'form-control'])); ?>

	   </div> 
	   <div class="form-group">
		<?php echo e(Form::label('message', '')); ?>	<?php echo e(Form::textarea('message', '',['placeholder' => 'Enter Message','class'=>'form-control'])); ?>


	   </div>
	   <div >
	   	<?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

	   </div>
   </div>
   
    
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/contact.blade.php ENDPATH**/ ?>