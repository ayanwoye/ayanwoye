<?php $__env->startSection('head'); ?>

    <script type="text/javascript">

        function block_rightclick(event){
            //return false;

        }
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



    <?php if(count($errors)>0): ?>
        <?php $__currentLoopData = $errors-> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger">
                <?php echo e($erro); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div class="alert alert-info">

        <a class="btn btn-link"  href="<?php echo e(url('/taketest')); ?>">   Retake Test</a>
        <a class="btn btn-link"  href="<?php echo e(url('/taketest')); ?>">   Quck Test</a>
        <a class="btn btn-link"  href="<?php echo e(url('/taketest')); ?>">   Quiz</a>
        <a class="btn btn-link" href="<?php echo e(url('/settest')); ?>">Custom Test</a>
        <a class="btn btn-link" href="<?php echo e(url('/')); ?>">Take Another</a>
        <a class="btn btn-warning" href="<?php echo e(url('/')); ?>">Marking Sheet</a>

    </div>

    <form action="<?php echo e(route('taketest')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="">
            <div class="form-group" >
                <div id="buttonss" class="btn btn-warning">
                    Show Analysis
                </div>
                <div id="buttonss" class="btn btn-primary">
                    Take Another

                </div>
                <button class="btn btn-info" type="button">
                    Retake Test

                </button>
            </div>

            <div class="">
                <label >
                    Time Needed(Minutes)
                    <input type="number" class="form-check-input" max="10" min="1">
                </label>
            </div>
            <div class="">
                <label >
                    Number of Questions
                    <input type="number" value="10" min="1" style="" name="questions" class="form-check-input" max="10">
                </label>
            </div>
            <div class="form-group">
                <label>
                    Level
                    <select  name="select" class="breadcrumb" >
                        <option value="1">Easy</option>
                        <option value="2">O-level</option>
                        <option value="3">A-level</option>
                    </select>
                </label>
            </div>
            <div >
                <?php echo e(Form::Submit('Submit', ['class'=>'btn btn-primary','onclick'=>"bb()"])); ?>

            </div>
            <div >
                <div id="buttonss" class="btn btn-warning">
                    Show Analysis
                </div>
                <div id="buttons" class="btn btn-primary">
                    Take Another
                </div>
                <button class="btn btn-info" type="button">
                    Retake Test
                </button>
            </div>
        </div>
    </form>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/test/settest.blade.php ENDPATH**/ ?>