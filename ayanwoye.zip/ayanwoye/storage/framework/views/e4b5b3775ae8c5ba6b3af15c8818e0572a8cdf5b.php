<?php $__env->startSection('content'); ?>
<h1>home</h1>
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto eius molestiae voluptatibus minima voluptates voluptatum soluta blanditiis commodi ratione aliquid, iste incidunt corrupti debitis, porro minus voluptate obcaecati dolorum illo.

<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>

<h1>home</h1>
<a href="about">about</a>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/home.blade.php ENDPATH**/ ?>