 <?php $__env->startSection('head'); ?>
   
   <script type="text/javascript"  >
	   function checker(){
		   
		   if(document.getElementById("question").value!=undefined){aa.submit();}
	   }
	   function ofe(){
		   var div = document.getElementById('oooo');
	 $("#oooo").fadeOut();
	//div.style.visibility = "hidden";div.style.display = "none";
	$("#oo").fadeIn(2000);div = document.getElementById('oo');
	div.style.visibility = "visible";
	div.style.display = "block";
	   }
function bb(vv){
	
	
	document.getElementById("question").value=vv.question;
	document.getElementById("one").value=vv.one;
	document.getElementById("two").value=vv.two;
	document.getElementById("three").value=vv.three;
	document.getElementById("four").value=vv.four;
	//document.getElementById("five").value=vv.five;
	aa.id.value = vv.id;
	//alert (vv.id);
	
	
}
	   function bbb(vv){
	
	
	aaa.id.value = vv;
		   aaa.submit();
	//alert (vv.id);
	
	
}
</script> 

   <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div>
		<h1>Messages</h1>
		<span><a href="<?php echo e(route('uploadquestion')); ?>">Upload More Questions</a></span>

	</div>
	
		<?php if(count($messages)>0 && $seed=='1'): ?>
		 	  <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		 	  <ul class="list-group">
		 	  <li class="list-group-item">Name: <?php echo e($message->name); ?></li>
		 	  <li class="list-group-item">Email:<?php echo e($message->email); ?></li>
		 	  <li class="list-group-item">Message:<?php echo e($message->messages); ?></li>
		 	  </ul>
		 	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
		<?php elseif(count($messages)>0 && $seed=='2'): ?>
		<?php echo Form::open(['url' => "deletequestion/submit",'name' => 'aaa']); ?> 	 <?php echo e(Form::hidden('id', '')); ?>

		<?php echo Form::close(); ?> 
		
		
		<?php echo Form::open(['url' => "updatequestion/submit",'name' => 'aa']); ?> 	 <?php echo e(Form::hidden('id', '')); ?>	 	  
<?php if(count($errors)>0): ?>
		 	  <?php $__currentLoopData = $errors-> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		 	  <div class="alert alert-danger">
		 	  	<?php echo e($erro); ?>

		 	  </div>
		 	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 	<?php endif; ?>
	<div id="oo" style="visibility: hidden;display: none">
   
	   <div class="form-group">
		<?php echo e(Form::label('Question', '')); ?>

		<?php echo e(Form::text('question', '',['placeholder' => 'Enter Question','class'=>'form-control','id'=>'question'])); ?>

	   </div>
	   <div class="form-group">

		<?php echo e(Form::label('Correct option', '')); ?>

		<?php echo e(Form::text('one', '',['placeholder' => 'Enter Correct Option','class'=>'form-control','id'=>'one'])); ?>

	   </div> 
	   <div class="form-group">

		<?php echo e(Form::label('Different option', '')); ?>

		<?php echo e(Form::text('two', '',['placeholder' => 'Enter Another Option','class'=>'form-control','id'=>'two'])); ?>

	   </div>
	   <div class="form-group">

		<?php echo e(Form::label('Different option', '')); ?>

		<?php echo e(Form::text('three', '',['placeholder' => 'Enter Another Option','class'=>'form-control','id'=>'three'])); ?>

	   </div>
	   <div class="form-group">

		<?php echo e(Form::label('Different option', '')); ?>

		<?php echo e(Form::text('four', '',['placeholder' => 'Enter Another Option','class'=>'form-control','id'=>'four'])); ?>

	   </div>
	   
	   <div >
	   	<?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

	   </div>
   </div>
   
		 
		 </div>
		<div id="oooo">  
		 	  <?php echo e(Form::checkbox('Edit All','m',false, ['id' => 'all'])); ?>

		 	  <?php echo e(Form::label('all','Edit all Questions' )); ?> 
		 	  <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		 	  
		 	  <ul class="list-group">
		 	  <li class="list-group-item">
		 	  	<?php echo e(Form::checkbox('edit',$message->id,false , ['id' => $message->id])); ?> <?php echo e(Form::label($message->id,'Edit Question:' )); ?> <?php echo e($message->question); ?>

		 	  </li>
		 	  <li class="list-group-item">Option:<?php echo e($message->one); ?></li>
		 	  <li class="list-group-item">Option:<?php echo e($message->two); ?></li>
		 	  <li class="list-group-item">Option:<?php echo e($message->three); ?></li>
		 	  <li class="list-group-item">Option:<?php echo e($message->four); ?></li>
		 	  <li class="list-group-item">Option:<?php echo e($message->five); ?></li>
		 	  <li class="list-group-item">Correct Option:<?php echo e($message->answer); ?></li>
		 	  
		 	  <li class="list-group-item">
		 	  <button type="button" name="<?php echo e($message->id); ?>" class="btn btn-primary btn-xs" onClick="bb(<?php echo e($message); ?>);ofe()">Edit</button>
		 	  <button type="button" name="<?php echo e($message->id); ?>" class="btn btn-danger btn-xs" onClick="bbb(<?php echo e($message->id); ?>)">Delete</button>  
		 	  </li>
		 	  </ul>
		 	  
		 	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php echo Form::close(); ?> 	  
		 	<?php endif; ?>
		 
	</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/messages.blade.php ENDPATH**/ ?>