<?php $__env->startSection('content'); ?>
<h1>About</h1>
	about test run Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sint id fugit, atque sed asperiores assumenda, odio fuga animi repudiandae nostrum facilis quos expedita maiores ut omnis hic doloremque commodi libero.
<a href="open" >efrfrergterttrgertver</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/about.blade.php ENDPATH**/ ?>