<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo e(config('app.name','Starter Sam')); ?></title>
 <link rel="stylesheet" href="/css/appp.css">
 <link rel="icon" href="/img/img.png">
 <script type="text/javascript" src="/js/app.js"></script> 
 <script type="text/javascript">
	
	//function aa(event){return false;}
	</script>
<?php echo $__env->yieldContent('head'); ?>
</head>

<body oncontextmenu="return block_rightclick(event);">
<?php echo $__env->make('navbar.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container">

      <!--  -->
 <div class="row">
 	<div class="col-md-8 col-lg-8 ">
		 	<?php if(session('success')): ?>
                <div class="alert alert-success">
                   <h1 class="text-uppercase"><?php echo e(Auth::user()->name); ?></h1>  <?php echo e(session('success')); ?>

                </div>
                <?php elseif(Request::is('/') || Request::is('home')): ?>
                    <?php echo $__env->make('inc.greet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		 	<?php endif; ?>
 		 <?php echo $__env->yieldContent('content'); ?>
 	</div>
 	<div class="col-md-4 col-lg-4 ">
 		<?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 	</div>
 </div>
 
</div>
<div id="footer" class="footer">
<footer id="footer" class="text-center">Copyright &copy; AyanGbaJesu</footer>
</div>
 


 
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/layout/app.blade.php ENDPATH**/ ?>