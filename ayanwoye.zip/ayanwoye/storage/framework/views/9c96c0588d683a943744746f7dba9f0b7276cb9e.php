 <?php $__env->startSection('head'); ?>
   
   <script type="text/javascript"  >
	   function checker(){
		  // document.getElementById("question").value || document.getElementById("one").value ||
		   if( document.getElementById("two").value==''){
			   //alert('sss');
			   $("span").toggle();
			   
			   //$("input").addClass('alert alert-danger');
			  // $("input").removeAttr('placeholder');
			   //$("input").a('alert alert-danger');
		   
		   }
		   else{
			  aa.submit();
		   }
	   }




</script> 

   <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<h1>
    <span>Upload Questionsss<br></span></h1>
	<span><a href="<?php echo e(route('amala')); ?>" > See Previous Uploaded Questions</a></span>

		<?php if(count($errors)>0): ?>
		 	  <?php $__currentLoopData = $errors-> all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $erro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		 	  <div class="alert alert-danger">
		 	  	<?php echo e($erro); ?>

		 	  </div>
		 	  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		 	<?php endif; ?>
<?php echo Form::open(['url' => 'uploadquestion/submit','name'=>'aa']); ?>

  <div class="">
	   <div class="form-group">
		<?php echo e(Form::label('Question', '')); ?>

		<?php echo e(Form::text('question', '',['placeholder' => 'Enter Question','class'=>'form-control','id'=>'question'])); ?>

	   </div>
	   <div class="form-group">

		<?php echo e(Form::label('Correct option', '')); ?>

		<?php echo e(Form::text('one', '',['placeholder' => 'Enter Correct Option','class'=>'form-control','id'=>'one'])); ?>

	   </div> 
	   <div class="form-group">

		<?php echo e(Form::label('Different option', '')); ?>

		<?php echo e(Form::text('two', '',['placeholder' => 'Enter Another Option','class'=>'form-control','id'=>'two'])); ?>

	   </div>
	   <div class="form-group">

		<?php echo e(Form::label('Different option', '')); ?>

		<?php echo e(Form::text('three', '',['placeholder' => 'Enter Another Option','class'=>'form-control'])); ?>

	   </div>
	   <div class="form-group">

		<?php echo e(Form::label('Different option', '')); ?>

		<?php echo e(Form::text('four', '',['placeholder' => 'Enter Another Option','class'=>'form-control'])); ?>

	   </div>
	   
	   <div >
	   	<?php echo e(Form::button('Submit', ['class'=>'btn btn-primary','onclick'=>'checker()'])); ?>

	   </div>
   </div>
   
    
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/test/uploadquestion.blade.php ENDPATH**/ ?>