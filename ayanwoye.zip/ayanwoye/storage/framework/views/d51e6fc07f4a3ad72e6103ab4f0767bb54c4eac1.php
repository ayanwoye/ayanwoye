

 <div class="well">
 <h3>sidebar</h3>
 this is the sidebar
<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->yieldSection(); ?>
 
</div><?php /**PATH C:\xampp\htdocs\ayanwoye\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>