<?php

Route::get('/', function () {
    return view('home');
});

Route::get('/card', 'CardController@index');
Route::get('/card/{card}', 'CardController@one');
Route::post('/card/{card}/note', 'CardController@addnote');
Route::get('/note/{note}/edit', 'CardController@editnote');
Route::patch('/note/{note}/updatenote', 'CardController@updatenote');





Route::get('/taketest/submit', 'PagesController@about');

//Route::get('/', 'PagesController@index');

Route::get('about', 'PagesController@about');

Route::get('contact', 'PagesController@contact');


Route::post('/contact/submit', 'PagesController@submit');

Route::post('/updatequestion/submit', 'PagesController@tak');

Route::post('/deletequestion/submit', 'PagesController@ta');

Route::post('/taketest/submit', 'PagesController@taken');

Route::post('/uploadquestion/submit', 'PagesController@submituploadquestion');

Route::get('/messages', 'PagesController@getMessages');

Route::get('/see', 'PagesController@seeq')->name('amala');

Route::get('/taketest', 'PagesController@taketest')->name('taketest');

Route::post('/taketest', 'PagesController@taketest');

Route::get('/wel', function () {
    return view('welcome');
})->middleware('auth');

Route::get('/open', function () {
    return view('test/open');
});






Route::get('/settest', 'PagesController@settest')->name('settest');


Auth::routes();

Route::get('/c', function () {
    return "vdccs";
});

Route::get('/home', 'HomeController@index')->name('ho');

Route::get('/uploadquestion', 'HomeController@uploadquestion')->name('uploadquestion');


