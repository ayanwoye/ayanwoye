
@extends('layout.app')

 @section('head')
   
   <script type="text/javascript"  >
	   function checker(){
		  // document.getElementById("question").value || document.getElementById("one").value ||
		   if( document.getElementById("two").value==''){
			   //alert('sss');
			   $("span").toggle();
			   
			   //$("input").addClass('alert alert-danger');
			  // $("input").removeAttr('placeholder');
			   //$("input").a('alert alert-danger');
		   
		   }
		   else{
			  aa.submit();
		   }
	   }




</script> 

   @endsection('head')
@section('content')

<h1>
    <span>Upload Questions<br></span></h1>
	<span><a href="{{route('amala')}}" > See Previous Uploaded Questions</a></span>

		@if(count($errors)>0)
		 	  @foreach($errors-> all() as $erro)
		 	  <div class="alert alert-danger">
		 	  	{{$erro}}
		 	  </div>
		 	  @endforeach
		 	@endif
{!! Form::open(['url' => 'uploadquestion/submit','name'=>'aa']) !!}
  <div class="">
	   <div class="form-group">
		{{Form::label('Question', '')}}
		{{Form::text('question', '',['placeholder' => 'Enter Question','class'=>'form-control','id'=>'question'])}}
	   </div>
	   <div class="form-group">

		{{Form::label('Correct option', '')}}
		{{Form::text('one', '',['placeholder' => 'Enter Correct Option','class'=>'form-control','id'=>'one'])}}
	   </div> 
	   <div class="form-group">

		{{Form::label('Different option', '')}}
		{{Form::text('two', '',['placeholder' => 'Enter Another Option','class'=>'form-control','id'=>'two'])}}
	   </div>
	   <div class="form-group">

		{{Form::label('Different option', '')}}
		{{Form::text('three', '',['placeholder' => 'Enter Another Option','class'=>'form-control'])}}
	   </div>
	   <div class="form-group">

		{{Form::label('Different option', '')}}
		{{Form::text('four', '',['placeholder' => 'Enter Another Option','class'=>'form-control'])}}
	   </div>
	   
	   <div >
	   	{{Form::button('Submit', ['class'=>'btn btn-primary','onclick'=>'checker()'])}}
	   </div>
   </div>
   
    
{!! Form::close() !!}
@endsection