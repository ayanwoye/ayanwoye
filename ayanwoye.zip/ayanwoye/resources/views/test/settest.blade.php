@extends('layout.app')

@section('head')

    <script type="text/javascript">

        function block_rightclick(event){
            //return false;

        }
    </script>

@endsection('head')
@section('content')



    @if(count($errors)>0)
        @foreach($errors-> all() as $erro)
            <div class="alert alert-danger">
                {{$erro}}
            </div>
        @endforeach
    @endif
    <div class="alert alert-info">

        <a class="btn btn-link"  href="{{ url('/taketest') }}">   Retake Test</a>
        <a class="btn btn-link"  href="{{ url('/taketest') }}">   Quck Test</a>
        <a class="btn btn-link"  href="{{ url('/taketest') }}">   Quiz</a>
        <a class="btn btn-link" href="{{ url('/settest') }}">Custom Test</a>
        <a class="btn btn-link" href="{{ url('/') }}">Take Another</a>
        <a class="btn btn-warning" href="{{ url('/') }}">Marking Sheet</a>

    </div>

    <form action="{{route('taketest')}}" method="post">
        @csrf
        <div class="">
            <div class="form-group" >
                <div id="buttonss" class="btn btn-warning">
                    Show Analysis
                </div>
                <div id="buttonss" class="btn btn-primary">
                    Take Another

                </div>
                <button class="btn btn-info" type="button">
                    Retake Test

                </button>
            </div>

            <div class="">
                <label >
                    Time Needed(Minutes)
                    <input type="number" class="form-check-input" max="10" min="1">
                </label>
            </div>
            <div class="">
                <label >
                    Number of Questions
                    <input type="number" value="10" min="1" style="" name="questions" class="form-check-input" max="10">
                </label>
            </div>
            <div class="form-group">
                <label>
                    Level
                    <select  name="select" class="breadcrumb" >
                        <option value="1">Easy</option>
                        <option value="2">O-level</option>
                        <option value="3">A-level</option>
                    </select>
                </label>
            </div>
            <div >
                {{Form::Submit('Submit', ['class'=>'btn btn-primary','onclick'=>"bb()"])}}
            </div>
            <div >
                <div id="buttonss" class="btn btn-warning">
                    Show Analysis
                </div>
                <div id="buttons" class="btn btn-primary">
                    Take Another
                </div>
                <button class="btn btn-info" type="button">
                    Retake Test
                </button>
            </div>
        </div>
    </form>



@endsection('content')
