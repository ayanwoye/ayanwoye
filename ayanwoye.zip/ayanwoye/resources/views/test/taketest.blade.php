
@extends('layout.app')
       
   @section('head')
   
    <script type="text/javascript">
	
	function block_rightclick(event){
		//return false;

	}
	</script>

   @endsection('head')
   @section('content')
	   @if(count($errors)>0)
		  @foreach($errors-> all() as $erro)
			  <div class="alert alert-danger">
				{{$erro}}
			  </div>
		  @endforeach
	   @endif
			<div class="alert alert-info">
				<a class="btn btn-link"  href="{{ url('/taketest') }}">   Retake Test</a>
				<a class="btn btn-link"  href="{{ url('/taketest') }}">   Quck Test</a>
				<a class="btn btn-link"  href="{{ url('/taketest') }}">   Quiz</a>
				<a class="btn btn-link" href="{{ url('/settest') }}">Custom Test</a>
				<a class="btn btn-link" href="{{ url('/') }}">Take Another</a>
				<a class="btn btn-warning" href="{{ url('/') }}">Marking Sheet</a>

			</div>


	   {!! Form::open(['url' => "taketest/submit?u=ss"]) !!}

						<?php
						$number=0;
						if(session('a')!=null){
							$messages = session('a');
						}
						  ?>
					@if(count($messages)>0 && $seed=='3')
						  @foreach($messages as $message)
							<div class="form-group">
										<?php
										$boy=$message->id."hid";
										$boys=$message->answer;
										$boyss= utf8_encode($boys);
										?>
							    {{Form::hidden($boy, $boyss)}}
							    Question:{{++$number}}   {{$message->question}} <br />
										<?php $boy=$message->one.$message->created_at;  ?>
								{{Form::radio($message->id, $message->one,false,['id' => $boy ])}}
								{{Form::label($boy , $message->one)}}
										<?php $boy=$message->two.$message->created_at; ?>
								{{Form::radio($message->id, $message->two,false,['id' => $boy])}}
								{{Form::label($boy, $message->two)}}
										<?php $boy=$message->three.$message->created_at; ?>
								{{Form::radio($message->id, $message->three,false,['id' => $boy])}}
											{{Form::label($boy, $message->three)}}

								<?php $boy=$message->four.$message->created_at;  ?>
								{{Form::radio($message->id, $message->four,false,['id' => $boy])}}
								{{Form::label($boy, $message->four)}}
							</div>
						  @endforeach
						  <div >
							  {{Form::Submit('Submit', ['class'=>'btn btn-primary','onclick'=>"bb()"])}}
						  </div>
					@elseif(count($messages)>0 && $seed=='taken')
						<div class="alert alert-danger">
							Your score is {{$boyy}} out of {{$boboo}}

						</div>
						<div >
							<div id="buttonss" class="btn btn-warning">
								Show Analysis
							</div>
							<div id="buttonss" class="btn btn-primary">
								Take Another

							</div>
							<button class="btn btn-info" type="button">
								Retake Test

							</button>
						</div>
						<div id="result_check">
						  @foreach($messages as $message)
							  <div class="form-group"  >
								  <?php
								  $boy=$message->id."hid";
								  $boys=$message->answer;
								  $boyss= utf8_encode($boys);
								  ?>
								  <ul class="list-group">
									  <li class="list-group-item">
										  Question:{{++$number}}   {{$message->question}} <br />
									  </li>
									  <li class="list-group-item " style="">
										  Answer:   {{$message->answer}} <br />
									  </li>
									  <li class="list-group-item"><?php  ?>
										  Your Answer:   {{isset($youranswers[$message->id])?$youranswers[$message->id]:'No answer given'}} <br />
									  </li>
									  <li class="list-group-item">
										  Given Options:
										  <ol class="">{{$message->one}}</ol>
										  <ol>{{$message->two}}</ol>
										  <ol>{{$message->three}}</ol>
										  <ol>{{$message->four}}</ol>
									  </li>
								  </ul>
							  </div>
						  @endforeach
							<div >
								<div id="buttonss" class="btn btn-warning">
									Show Analysis
								</div>
								<div id="buttons" class="btn btn-primary">
									Take Another
								</div>
								<button class="btn btn-info" type="button">
									Retake Test
								</button>
							</div>
						</div>
					@endif
	   {!! Form::close() !!}
	   <script type="text/javascript">

		   $( document ).ready(function() {$('#result_check').hide();});
		   $( '.btn-warning').click(function() {
			   $('#result_check').toggle();
			   $(this).html()=="Hide Analysis"?$(this).html("Show Analysis"):$(this).html("Hide Analysis");
		   });
	   </script>
   @endsection('content')
   