@extends('layout.app')

 @section('head')
   
   <script type="text/javascript"  >
	   function checker(){
		   
		   if(document.getElementById("question").value!=undefined){aa.submit();}
	   }
	   function ofe(){
		   var div = document.getElementById('oooo');
	 $("#oooo").fadeOut();
	//div.style.visibility = "hidden";div.style.display = "none";
	$("#oo").fadeIn(2000);div = document.getElementById('oo');
	div.style.visibility = "visible";
	div.style.display = "block";
	   }
function bb(vv){
	
	
	document.getElementById("question").value=vv.question;
	document.getElementById("one").value=vv.one;
	document.getElementById("two").value=vv.two;
	document.getElementById("three").value=vv.three;
	document.getElementById("four").value=vv.four;
	//document.getElementById("five").value=vv.five;
	aa.id.value = vv.id;
	//alert (vv.id);
	
	
}
	   function bbb(vv){
	
	
	aaa.id.value = vv;
		   aaa.submit();
	//alert (vv.id);
	
	
}
</script> 

   @endsection('head')
@section('content')
	<div>
		<h1>Messages</h1>
		<span><a href="{{route('uploadquestion')}}">Upload More Questions</a></span>

	</div>
	
		@if(count($messages)>0 && $seed=='1')
		 	  @foreach($messages as $message)
		 	  <ul class="list-group">
		 	  <li class="list-group-item">Name: {{$message->name}}</li>
		 	  <li class="list-group-item">Email:{{$message->email}}</li>
		 	  <li class="list-group-item">Message:{{$message->messages}}</li>
		 	  </ul>
		 	  @endforeach   
		@elseif(count($messages)>0 && $seed=='2')
		{!! Form::open(['url' => "deletequestion/submit",'name' => 'aaa']) !!} 	 {{Form::hidden('id', '')}}
		{!! Form::close() !!} 
		
		
		{!! Form::open(['url' => "updatequestion/submit",'name' => 'aa']) !!} 	 {{Form::hidden('id', '')}}	 	  
@if(count($errors)>0)
		 	  @foreach($errors-> all() as $erro)
		 	  <div class="alert alert-danger">
		 	  	{{$erro}}
		 	  </div>
		 	  @endforeach
		 	@endif
	<div id="oo" style="visibility: hidden;display: none">
   
	   <div class="form-group">
		{{Form::label('Question', '')}}
		{{Form::text('question', '',['placeholder' => 'Enter Question','class'=>'form-control','id'=>'question'])}}
	   </div>
	   <div class="form-group">

		{{Form::label('Correct option', '')}}
		{{Form::text('one', '',['placeholder' => 'Enter Correct Option','class'=>'form-control','id'=>'one'])}}
	   </div> 
	   <div class="form-group">

		{{Form::label('Different option', '')}}
		{{Form::text('two', '',['placeholder' => 'Enter Another Option','class'=>'form-control','id'=>'two'])}}
	   </div>
	   <div class="form-group">

		{{Form::label('Different option', '')}}
		{{Form::text('three', '',['placeholder' => 'Enter Another Option','class'=>'form-control','id'=>'three'])}}
	   </div>
	   <div class="form-group">

		{{Form::label('Different option', '')}}
		{{Form::text('four', '',['placeholder' => 'Enter Another Option','class'=>'form-control','id'=>'four'])}}
	   </div>
	   
	   <div >
	   	{{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
	   </div>
   </div>
   
		 
		 </div>
		<div id="oooo">  
		 	  {{Form::checkbox('Edit All','m',false, ['id' => 'all'])}}
		 	  {{Form::label('all','Edit all Questions' )}} 
		 	  @foreach($messages as $message)
		 	  
		 	  <ul class="list-group">
		 	  <li class="list-group-item">
		 	  	{{Form::checkbox('edit',$message->id,false , ['id' => $message->id])}} {{Form::label($message->id,'Edit Question:' )}} {{$message->question}}
		 	  </li>
		 	  <li class="list-group-item">Option:{{$message->one}}</li>
		 	  <li class="list-group-item">Option:{{$message->two}}</li>
		 	  <li class="list-group-item">Option:{{$message->three}}</li>
		 	  <li class="list-group-item">Option:{{$message->four}}</li>
		 	  <li class="list-group-item">Option:{{$message->five}}</li>
		 	  <li class="list-group-item">Correct Option:{{$message->answer}}</li>
		 	  
		 	  <li class="list-group-item">
		 	  <button type="button" name="{{$message->id}}" class="btn btn-primary btn-xs" onClick="bb({{$message}});ofe()">Edit</button>
		 	  <button type="button" name="{{$message->id}}" class="btn btn-danger btn-xs" onClick="bbb({{$message->id}})">Delete</button>  
		 	  </li>
		 	  </ul>
		 	  
		 	  @endforeach
		{!! Form::close() !!} 	  
		 	@endif
		 
	</div>

@endsection

