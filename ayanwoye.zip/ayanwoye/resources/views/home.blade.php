@extends('layout.app')


@section('content')
<h1>home</h1>
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iusto eius molestiae voluptatibus minima voluptates voluptatum soluta blanditiis commodi ratione aliquid, iste incidunt corrupti debitis, porro minus voluptate obcaecati dolorum illo.

@endsection
@section('sidebar')

<h1>home</h1>
<a href="about">about</a>
@parent
@endsection