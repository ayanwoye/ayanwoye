@extends('layout.app')


@section('content')
<div class="row">
	<div class="">
		<h1>{{$card->title}}</h1>
		<ul class="list-group">
			@foreach($card->notes as $note)
				<li class="list-group-item">{{$note->body}}
					<div style="float: right">
					<a href="/note/{{$note->id}}/edit"  > Edit note </a>&nbsp;&nbsp;&nbsp; 
					<a href=""  > Delete note </a>
					<b><a href=""  > {{$note->user->name}}</a></b>
					</div>
				</li>

			@endforeach
		</ul>
		
		{!! Form::open(['url' => "/card/".$card->id."/note",'name' => 'aaa']) !!} 	 {{Form::hidden('id', '')}}
			<div class="form-group">

			{{Form::label('Add notes to your Card', '')}}
			{{Form::text('body', '',['placeholder' => 'Add notes','class'=>'form-control','required'=>'true','id'=>'four'])}}
		   </div>
		   <div >
				{{Form::submit('Add Note', ['class'=>'btn btn-primary'])}}
		   </div>
		{!! Form::close() !!}
		
		@if(count($errors)>0)
		 	  @foreach($errors-> all() as $erro)
		 	  <div class="alert alert-danger">
		 	  	{{$erro}}
		 	  </div>
		 	  @endforeach
		 	@endif

	</div>
	
</div>
<a href="open" >efrfrergterttrgertver</a>
@endsection('content')