@extends('layout.app')


@section('content')
<div class="row">
	<div class="col-md-5 col-md-offset-1">
		<h1>Edit Note</h1><h2>{{$ss->title}}</h2>
		
		
		{!! Form::open(['url' => "/note/".$card->id."/updatenote",'name' => 'aaa']) !!} 	 {{Form::hidden('_method', 'PATCH')}}
			<div class="form-group">

			{{Form::label('Edit note in your Card', '')}}
			{{Form::text('body', $card->body,['placeholder' => 'Edit note','class'=>'form-control','id'=>'four'])}}
		   </div>

		   <div >
				{{Form::submit('Update Note', ['class'=>'btn btn-primary'])}}
		   </div>
		{!! Form::close() !!}
		
		

	</div>
	
</div>
<a href="open" >efrfrergterttrgertver</a>
@endsection('content')