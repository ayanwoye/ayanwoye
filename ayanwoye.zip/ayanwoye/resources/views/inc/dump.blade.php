DB_DATABASE=basicwebsite
DB_USERNAME=root
DB_PASSWORD=''





//$ra = mt_rand(0,--$aa);


{{Form::button('Edit', ['class'=>'btn btn-info btn-xs','value'=>$message->id,'name'=>$message->id,'onclick'=>'bb("n")'])}}  {{Form::Submit('Delete', ['class'=>'btn btn-warning btn-xs'])}}
  

  $dd = json_decode(json_encode($messages), true);
//$aa = count($dd);
	//print_r($dd[1]);	
// rsort($dd);echo 'vvvvvv';
//print_r($dd[1]);
     $raa =[];
	$aa = count($dd);
	for($ss=4;$ss>=0;--$ss) {
		
		
		$ra = mt_rand(0,$ss);
		 array_push($raa,$dd[$ra]);
		if($aa>0){
			//print_r($dd[$ra]['question']);
		$dad = array_splice($dd, $ra ,1);
			
			//print_r($dad); 
		}//unset($dd[$ra]));
    //echo "Key=" . "$x" . ", rrValue=". $ra .$aa;
		//echo "<br>";
		//PagesController@index;
  // print_r($aa);
	//	print_r($ss);echo "ss";
		//print_r($dd);
		
	
}
$messages = json_decode(json_encode($raa), false);
//print_r($raa[4]);


  
  
  
  
  
  
   

   $age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
foreach($messages as  $x_value) {
    echo "Key=" . "x" . ", Value=" . $x_value;
    echo "<br>";
	foreach($x_value as  $y_value) {
		echo "Key=" . "x" . ", Value=" . $y_value;
		echo "<br>";
	}
}
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   <div class="form-group">
	   Who is the president of Nigeria <br />
	    
	    {{Form::radio('one', '1',false,['id' => 'one1'])}}
   		{{Form::label('one1', 'Buhari')}}
   		
   		
	    {{Form::radio('one', '2',false,['id' => 'one2'])}}
	    {{Form::label('one2', 'Jonathan')}}
	  
	    {{Form::radio('one', '3',false,['id' => 'one3'])}}
	      {{Form::label('one3', 'Obasanjo')}}
	    
	    {{Form::radio('one', '4',false,['id' => 'one4'])}}
	    {{Form::label('one4', 'Babangida')}}
	   </div>
	   
	    <div class="form-group">
	   Who is the Vice president of Nigeria <br />
	    
	    {{Form::radio('two', '1',false,['id' => 'two1'])}}
   		{{Form::label('two1', 'Osibanjo')}}
   		
   		
	    {{Form::radio('two', '2',false,['id' => 'two2'])}}
	    {{Form::label('two2', 'Atiku')}}
	  
	    {{Form::radio('two', '3',false,['id' => 'two3'])}}
	      {{Form::label('two3', 'Obasanjo')}}
	    
	    {{Form::radio('two', '4',false,['id' => 'two4'])}}
	    {{Form::label('two4', 'Babangida')}}
	   </div>
	   
	   
	   for ($row = 1; $row < 5; $row++) {
  echo "<p><b>Row number $row</b></p>";
  echo "<ul>";
  for ($col = 1; $col < 4; $col++) {
    echo "<li>".$messages[$row][$col]."</li>";
  }
  echo "</ul>";
}
	   
	  
	 
	



//time
Calendar cal = Calendar.getInstance();
      long currentTime = cal.getTimeInMillis();
      long Max = 9999999999999L;
      long Min = 1000000000000L;
    long range = Math.abs((long) (Math.random() * (Max - Min)) + Min);
    long id = Math.addExact(currentTime, range);
    String uniqueID = createUniqueID(id);
    boolean isRepeated = urlShortenerRepository.existsByShortUrlKey(uniqueID);
    while (isRepeated) {
        range = Math.abs((long) (Math.random() * (Max - Min)) + Min);
        id = Math.addExact(currentTime, range);
        uniqueID = createUniqueID(id);
        isRepeated = urlShortenerRepository.existsByShortUrlKey(uniqueID);
    }