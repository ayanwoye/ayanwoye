<div class="jumbotron text-uppercase text-center">
	<h1>
	@auth
		{{ Auth::user()->name }} 
	@endauth
	</h1>
	<h2> welcome to hope and anchor home page</h2>
	<div class="lead">
	This is powered by the kaffin koro division </div>
</div>