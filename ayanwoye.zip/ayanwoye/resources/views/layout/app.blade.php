<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>{{config('app.name','Starter Sam')}}</title>
 <link rel="stylesheet" href="/css/appp.css">
 <link rel="icon" href="/img/img.png">
 <script type="text/javascript" src="/js/app.js"></script> 
 <script type="text/javascript">
	
	//function aa(event){return false;}
	</script>
@yield('head')
</head>

<body oncontextmenu="return block_rightclick(event);">
@include('navbar.nav')
<div class="container">

      <!--  -->
 <div class="row">
 	<div class="col-md-8 col-lg-8 ">
		 	@if(session('success'))
                <div class="alert alert-success">
                   <h1 class="text-uppercase">{{ Auth::user()->name }}</h1>  {{session('success')}}
                </div>
                @elseif(Request::is('/') || Request::is('home'))
                    @include('inc.greet')
		 	@endif
 		 @yield('content')
 	</div>
 	<div class="col-md-4 col-lg-4 ">
 		@include('inc.sidebar')
 	</div>
 </div>
 
</div>
<div id="footer" class="footer">
<footer id="footer" class="text-center">Copyright &copy; AyanGbaJesu</footer>
</div>
 


 
</body>
</html>
