@extends('layout.app')
@section('content')
<h1>Contact</h1>
		@if(count($errors)>0)
		 	  @foreach($errors-> all() as $erro)
		 	  <div class="alert alert-danger">
		 	  	{{$erro}}
		 	  </div>
		 	  @endforeach
		 	@endif

{!! Form::open(['url' => 'contact/submit']) !!}
  <div class="">
	   <div class="form-group">
		{{Form::label('name', '')}}
		{{Form::text('name', '',['placeholder' => 'Enter Name','class'=>'form-control'])}}
	   </div>
	   <div class="form-group">

		{{Form::label('email', '')}}
		{{Form::text('email', '',['placeholder' => 'Enter Email','class'=>'form-control'])}}
	   </div> 
	   <div class="form-group">
		{{Form::label('message', '')}}	{{Form::textarea('message', '',['placeholder' => 'Enter Message','class'=>'form-control'])}}

	   </div>
	   <div >
	   	{{Form::submit('Submit', ['class'=>'btn btn-primary'])}}
	   </div>
   </div>
   
    
{!! Form::close() !!}
@endsection