@extends('layout.app')


@section('content')
	<h1>CARDS</h1>
	@foreach($cards as $card)
<a href="{{$card->path()}}"><h2>{{$card->title}}</h2></a>
	@endforeach
	
@endsection('content')