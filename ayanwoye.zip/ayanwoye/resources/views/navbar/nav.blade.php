<nav class="navbar navbar-inverse ">
	
	<div class="container">
	<div class="navbar-header">
	<button type="button" class="navbar-toggle collapsed" data-toggle="collaspe" >
	<span class="sr-only">Toggle navigation</span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
	<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="#">HOPE AND ANCHOR</a>
		 
	</div>
	<div id="navbar" class=""> 
	<ul class="nav navbar-nav">
		<li class="{{Request::is('/')?'active':''}}"><a href="/">Home</a></li>
		<li class="{{Request::is('taketest')?'active':''}}"><a href="{{ route('taketest') }}">Take Test</a></li>
		@auth
			<li class="{{Request::is('uploadquestion')?'active':''}}"><a href="{{ route('uploadquestion') }}">Upload Question</a></li>
		@else
            <li class="{{Request::is('uploadquestion')?'active':''}}"><a href="{{ route('login') }}">Login</a></li>
		    @if (Route::has('register'))
				<li class="{{Request::is('uploadquestion')?'active':''}}"><a href="{{ route('register') }}">Register</a>
			@endif
		@endauth
		<li class="{{Request::is('contact')?'active':''}}" ><a href="contact">Contact</a></li>
		<li class="{{Request::is('about')?'active':''}}" ><a href="about">About</a></li>
		@auth
		<li class="" ><a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a></li>
		@endauth

	</ul></div>	
		
	</div>
	

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
</nav>