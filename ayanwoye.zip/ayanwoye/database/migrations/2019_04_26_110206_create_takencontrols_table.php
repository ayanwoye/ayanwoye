<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTakencontrolsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('takencontrols', function (Blueprint $table) {
            $table->increments('id');
			$table->longText('question');
			$table->mediumText('one');
			$table->mediumText('two');
			$table->mediumText('three')->nullable();
			$table->mediumText('four')->nullable();
			$table->mediumText('five')->nullable();
			$table->char('nan',2)->nullable();
			$table->string('answer');
			
			
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('takencontrols');
    }
}
